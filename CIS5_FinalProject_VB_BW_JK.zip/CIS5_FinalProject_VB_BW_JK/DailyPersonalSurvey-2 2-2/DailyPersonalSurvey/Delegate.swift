//
//  Delegate.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/18/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import Foundation

// Note: this protocol is used in "Passing Data Back With Delegation"

protocol PizzaDelegate
{
    func onPizzaReady(type: String)
}
