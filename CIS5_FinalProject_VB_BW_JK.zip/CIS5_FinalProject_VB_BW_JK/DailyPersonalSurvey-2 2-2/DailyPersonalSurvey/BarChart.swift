////
////  BarChart.swift
////  DailyPersonalSurvey
////
////  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/9/18.
////  Copyright © 2018 DeAnza. All rights reserved.
////
//
//import UIKit
//import Charts
//
//class BarChart: UIView{
//    // Bar chart properties
//    //  var exampleString = String()
//    var barChartView = BarChartView()
//    var barDataEntry: [ChartDataEntry] = []
//     var MyMoods = [MoodObjectMO]()
//
//    // Chart data
////    var workoutDuration = [String]()
////    var beatsPerMinute = [String]()
//   // var delegate: GetChartdata //non-optional variable
//    func setBarChart(dataPoints: [MoodObjectMO]){
//
//        // No data setup
//        barChartView.noDataTextColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
//        barChartView.noDataText = "No data for the chart."
//        barChartView.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
//        // Data point setup & color config
//        //        for i in 0..<dataPoints.count{
//        //            let dataPoint = BarChartDataEntry(x: Double(i), y: Double(values[i])!)
//        //            dataEntry.append(dataPoint)
//        //        }
//
//        var moods = [String]()
//        for i in 0..<dataPoints.count{
//            print(String((dataPoints[i].mood)!))
//            print((dataPoints[i].date)!)
//            print(Double((dataPoints[i].mood)!)!)
//            let sDate = String((dataPoints[i].date)!)
//            let index = sDate.index(sDate.startIndex, offsetBy: 3)
//            let index2 = sDate.index(sDate.startIndex, offsetBy: 4)
//            let month = String(sDate[index])+String(sDate[index2])
//            print(Double(month)!)
//
//            let dataPoint = ChartDataEntry(x: Double((dataPoints[i].mood)!)!, y: Double((dataPoints[i].date)!)!)
//            barDataEntry.append(dataPoint)
//            moods.append(dataPoints[i].mood!)
////            let dataPoint = ChartDataEntry(x: Double((dataPoints[i].mood)!)!, y: Double((dataPoints[i].date)!)!)
////            barDataEntry.append(dataPoint as! BarChartDataEntry)
////            moods.append(dataPoints[i].mood!)
//        }
//
//        let chartDataSet = BarChartDataSet(values: barDataEntry, label: "Dates")
//        let chartData = BarChartData()
//        chartData.addDataSet(chartDataSet)
//        chartData.setDrawValues(false) // true if want values above bar
//        chartDataSet.colors = [UIColor.red]//themePink]
//
//        // Axes setup
//        let formatter: ChartFormatter = ChartFormatter()
//        formatter.setValues(values: moods)
//        let xaxis: XAxis = XAxis()
//        xaxis.valueFormatter = formatter
//        barChartView.xAxis.labelPosition = .bottom
//        barChartView.xAxis.drawGridLinesEnabled = false // true if you want X-Axis grid
//        barChartView.xAxis.valueFormatter = xaxis.valueFormatter
//        barChartView.chartDescription?.enabled = false
//        barChartView.legend.enabled = true
//        barChartView.rightAxis.enabled = true
//        barChartView.leftAxis.drawGridLinesEnabled = false // true if you want Y-Axis grid
//        barChartView.leftAxis.drawLabelsEnabled = true
//        barChartView.data = chartData
//    }
//
//    func barChartSetup(){
//        // Bar chart config
//        self.backgroundColor = UIColor.white
//        self.addSubview(barChartView)
//        barChartView.translatesAutoresizingMaskIntoConstraints = false
//        barChartView.topAnchor.constraint(equalTo: self.topAnchor, constant: 20).isActive = true
//        barChartView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
//        barChartView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
//        barChartView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
//
//        // Bar chart animation
//        barChartView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
//
//        // Bar chart population
//
//        setBarChart(dataPoints: MyMoods)
//    }
//
//    var delegate: GetChartdata! {
//        didSet {
//            populateData()
//            barChartSetup()
//        }
//    }
//
//    func populateData(){
//        MyMoods = delegate.MyMoods
//}
//
//}

