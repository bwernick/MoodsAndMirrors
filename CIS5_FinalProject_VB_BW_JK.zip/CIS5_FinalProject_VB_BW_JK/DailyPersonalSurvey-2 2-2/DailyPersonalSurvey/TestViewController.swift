//
////  TestViewController.swift
////  DailyPersonalSurvey
////
////  Created by Vera Boukhonine on 6/13/18.
////  Copyright © 2018 DeAnza. All rights reserved.
//
//
//import UIKit
//import CKCircleMenuView
//
//class TestViewController: UIViewController, CKCircleMenuDelegate {
//    @IBOutlet var clippingView: UIView!
//
//    var buttons = [AnyHashable]()
//    weak var recognizer: UIGestureRecognizer?
//    var hoverTag: Int = 0
//    var innerViewColor: UIColor?
//    var innerViewActiveColor: UIColor?
//    var borderViewColor: UIColor?
//    var radius: CGFloat = 0.0
//    var maxAngle: CGFloat = 0.0
//    var animationDelay: CGFloat = 0.0
//    var startingAngle: CGFloat = 0.0
//    var depth = false
//    var buttonRadius: CGFloat = 0.0
//    var buttonBorderWidth: CGFloat = 0.0
//    var tapMode = false
//    var absurdLineMode = false
//    var visualFxMode = false
//    var buttonTintMode = false
//    var allowAnimationInteraction = false
//    var buttonTitleVisible = false
//    var buttonTitleFontSize: CGFloat = 0.0
//
//    // each button is made up of two views (button image, and background view)
//    // the buttons get tagged, starting at 1
//    // components are identified by adding the corresponding offset to the button's logical tag
//
//    private var TAG_BUTTON_OFFSET: Int = 100
//    private var TAG_INNER_VIEW_OFFSET: Int = 1000
//
//    // constants used for the configuration dictionary
//
//    let CIRCLE_MENU_BUTTON_BACKGROUND_NORMAL = "kCircleMenuNormal"
//    let CIRCLE_MENU_BUTTON_BACKGROUND_ACTIVE = "kCircleMenuActive"
//    let CIRCLE_MENU_BUTTON_BORDER = "kCircleMenuBorder"
//    let CIRCLE_MENU_OPENING_DELAY = "kCircleMenuDelay"
//    let CIRCLE_MENU_RADIUS = "kCircleMenuRadius"
//    let CIRCLE_MENU_MAX_ANGLE = "kCircleMenuMaxAngle"
//    let CIRCLE_MENU_DIRECTION = "kCircleMenuDirection"
//    let CIRCLE_MENU_DEPTH = "kCircleMenuDepth"
//    let CIRCLE_MENU_BUTTON_RADIUS = "kCircleMenuButtonRadius"
//    let CIRCLE_MENU_BUTTON_BORDER_WIDTH = "kCircleMenuButtonBorderWidth"
//    let CIRCLE_MENU_TAP_MODE = "kCircleMenuTapMode"
//    let CIRCLE_MENU_LINE_MODE = "kCircleMenuLineMode"
//    let CIRCLE_MENU_BACKGROUND_BLUR = "kCircleMenuBackgroundBlur"
//    let CIRCLE_MENU_BUTTON_TINT = "kCircleMenuButtonTint"
//    let CIRCLE_MENU_ALLOW_ANIMATION_INTERACTION = "kCircleMenuAllowAnimationInteraction"
//    let CIRCLE_MENU_STARTING_ANGLE = "kCircleMenuStartingAngle"
//    let CIRCLE_MENU_BUTTON_TITLE_VISIBLE = "kCircleMenuButtonTitleVisible"
//    let CIRCLE_MENU_BUTTON_TITLE_FONT_SIZE = "kCircleMenuButtonTitleFontSize"
//    @objc init(options anOptionsDictionary: [AnyHashable: Any]?) {
//       super.init()
//
//        buttons = [AnyHashable]()
//        if anOptionsDictionary != nil {
//            innerViewColor = anOptionsDictionary?[CIRCLE_MENU_BUTTON_BACKGROUND_NORMAL] as? UIColor
//            innerViewActiveColor = anOptionsDictionary?[CIRCLE_MENU_BUTTON_BACKGROUND_ACTIVE] as? UIColor
//            borderViewColor = anOptionsDictionary?[CIRCLE_MENU_BUTTON_BORDER] as? UIColor
//            animationDelay = Double(anOptionsDictionary?[CIRCLE_MENU_OPENING_DELAY] ?? 0.0)
//            radius = Double(anOptionsDictionary?[CIRCLE_MENU_RADIUS] ?? 0.0)
//            maxAngle = Double(anOptionsDictionary?[CIRCLE_MENU_MAX_ANGLE] ?? 0.0)
//            switch Int(anOptionsDictionary?[CIRCLE_MENU_DIRECTION] ?? 0) {
//            case Int(CircleMenuDirectionUp):
//                startingAngle = 0.0
//            case Int(CircleMenuDirectionRight):
//                startingAngle = 90.0
//            case Int(CircleMenuDirectionDown):
//                startingAngle = 180.0
//            case Int(CircleMenuDirectionLeft):
//                startingAngle = 270.0
//            }
//            // if CIRCLE_MENU_STARTING_ANGLE is set, override startingAngle derived from direction
//            if anOptionsDictionary?[CIRCLE_MENU_STARTING_ANGLE] != nil {
//                startingAngle = Double(anOptionsDictionary?[CIRCLE_MENU_STARTING_ANGLE] ?? 0.0)
//            }
//            depth = anOptionsDictionary?[CIRCLE_MENU_DEPTH] != 0
//            buttonRadius = Double(anOptionsDictionary?[CIRCLE_MENU_BUTTON_RADIUS] ?? 0.0)
//            buttonBorderWidth = Double(anOptionsDictionary?[CIRCLE_MENU_BUTTON_BORDER_WIDTH] ?? 0.0)
//            tapMode = anOptionsDictionary?[CIRCLE_MENU_TAP_MODE] != 0
//            absurdLineMode = anOptionsDictionary?[CIRCLE_MENU_LINE_MODE] != 0
//            if absurdLineMode {
//                startingAngle += 90.0
//            }
//            visualFxMode = anOptionsDictionary?[CIRCLE_MENU_BACKGROUND_BLUR] != 0
//            buttonTintMode = anOptionsDictionary?[CIRCLE_MENU_BUTTON_TINT] != 0
//            allowAnimationInteraction = anOptionsDictionary?[CIRCLE_MENU_ALLOW_ANIMATION_INTERACTION] != 0
//            buttonTitleVisible = anOptionsDictionary?[CIRCLE_MENU_BUTTON_TITLE_VISIBLE] != 0
//            buttonTitleFontSize = Double(anOptionsDictionary?[CIRCLE_MENU_BUTTON_TITLE_FONT_SIZE] ?? 0.0)
//            if !buttonTitleFontSize {
//                buttonTitleFontSize = 11.0
//            }
//        } else {
//            // using some default settings
//            innerViewColor = UIColor(red: 0.0, green: 0.25, blue: 0.5, alpha: 1.0)
//            innerViewActiveColor = UIColor(red: 0.25, green: 0.5, blue: 0.75, alpha: 1.0)
//            borderViewColor = UIColor.white
//            animationDelay = 0.0
//            radius = 65.0
//            maxAngle = 180.0
//            startingAngle = 0.0
//            depth = false
//            buttonRadius = 39.0
//            buttonBorderWidth = 2.0
//            tapMode = false
//            absurdLineMode = false
//            visualFxMode = false
//            buttonTintMode = false
//            allowAnimationInteraction = false
//            buttonTitleVisible = false
//            buttonTitleFontSize = 11.0
//        }
//
//    }
//    @objc func initAtOrigin(_ aPoint: CGPoint, usingOptions anOptionsDictionary: [AnyHashable: Any]?, withImageArray anImageArray: [Any]?) -> Any? {
//        self = initAtOrigin(aPoint, usingOptions: anOptionsDictionary, withImageArray: anImageArray, andTitles: [])
//        return self
//    }
//    @objc func initAtOrigin(_ aPoint: CGPoint, usingOptions anOptionsDictionary: [AnyHashable: Any]?, withImageArray anImageArray: [Any]?, andTitles aTitleArray: [Any]?) -> Any? {
//        self.type(of: init)(options: anOptionsDictionary)
//
//        var tTag: Int = 1
//        for img: UIImage? in anImageArray as? [UIImage?] ?? [UIImage?]() {
//            var tView: UIView?
//            if (aTitleArray?.count ?? 0) >= tTag {
//                tView = createButtonView(with: img, andTag: tTag, andTitle: aTitleArray?[tTag - 1])
//            } else {
//                tView = createButtonView(with: img, andTag: tTag, andTitle: nil)
//            }
//            if let aView = tView {
//                buttons.append(aView)
//            }
//            tTag += 1
//        }
//        self.frame = self.calculateFrame(withOrigin: aPoint)
//
//        return self
//    }
//    @objc func initAtOrigin(_ aPoint: CGPoint, usingOptions anOptionsDictionary: [AnyHashable: Any]?, withImages anImage: UIImage?) -> Any? {
//        self.type(of: init)(options: anOptionsDictionary)
//
//        var tTag: Int = 1
//        let args: va_list
//        va_start(args, anImage)
//        var img = anImage
//        while img != nil {
//            let tView: UIView? = createButtonView(with: img, andTag: tTag, andTitle: nil)
//            if let aView = tView {
//                buttons.append(aView)
//            }
//            tTag += 1
//            img = va_rea(args, UIImage)
//        }
//        vm_rea, <#vm_address_t#>d(args)
//        frame = calculateFrame(withOrigin: aPoint)
//
//        return self
//    }
//    func calculateFrame(withOrigin aPoint: CGPoint) -> CGRect {
//        var tFrame: CGRect
//        if absurdLineMode {
//            // calculate maximum bounding box, independent of actual direction
//            let tMaximumButtonDistance: CGFloat = (2 * buttonRadius + 8.0) * buttons.count
//            tFrame = CGRect(x: aPoint.x - radius - tMaximumButtonDistance, y: aPoint.y - radius - tMaximumButtonDistance, width: radius * 2 + tMaximumButtonDistance * 2, height: radius * 2 + tMaximumButtonDistance * 2)
//        } else {
//            tFrame = CGRect(x: aPoint.x - radius - buttonRadius, y: aPoint.y - radius - buttonRadius, width: radius * 2 + buttonRadius * 2, height: radius * 2 + buttonRadius * 2)
//        }
//        return tFrame
//    }
//    /**
//     * Convenience method that creates a circle button, consisting of
//     * the image, a background and a border.
//     * @param anImage image to be used as button's icon
//     * @param aTag unique identifier (should be index + 1)
//     * @return UIView to be used as button
//     */
//
//    func createButtonView(with anImage: UIImage?, andTag aTag: Int, andTitle aTitle: String?) -> UIView? {
//        var tButton: UIButton?
//        if buttonTintMode {
//            tButton = UIButton(type: .system)
//        } else {
//            tButton = UIButton(type: .custom)
//        }
//        if absurdLineMode {
//            tButton?.frame = CGRect(x: 0.0, y: 0.0, width: buttonRadius * 2, height: buttonRadius * 2)
//        } else {
//            let tButtonViewX: CGFloat = buttonRadius - (anImage?.size.width ?? 0.0) / 2
//            let tButtonViewY: CGFloat = buttonRadius - (anImage?.size.height ?? 0.0) / 2
//            tButton?.frame = CGRect(x: tButtonViewX, y: tButtonViewY, width: anImage?.size.width ?? 0.0, height: anImage?.size.height ?? 0.0)
//        }
//        tButton?.setImage(anImage, for: .normal)
//        tButton?.tag = aTag + TAG_BUTTON_OFFSET
//        let tInnerView = CKRoundView(frame: CGRect(x: 0.0, y: 0.0, width: buttonRadius * 2, height: buttonRadius * 2)) as? UIView
//        tInnerView?.backgroundColor = innerViewColor
//        tInnerView?.isOpaque = true
//        tInnerView?.clipsToBounds = false
//        tInnerView?.layer.cornerRadius = buttonRadius
//        tInnerView?.layer.borderColor = borderViewColor?.cgColor
//        tInnerView?.layer.borderWidth = buttonBorderWidth
//        if depth {
//            applyInactiveDepth(toButtonView: tInnerView)
//        }
//        // Support for displaying button titles
//        if buttonTitleVisible && aTitle != nil {
//            let tLabel = UILabel(frame: CGRect(x: 0.0, y: buttonRadius * 2 - buttonTitleFontSize * 2.15, width: buttonRadius * 2, height: buttonTitleFontSize + 2.0))
//            tLabel.textAlignment = .center
//            tLabel.font = UIFont.systemFont(ofSize: buttonTitleFontSize)
//            tLabel.textColor = borderViewColor
//            tLabel.text = aTitle
//            tLabel.isUserInteractionEnabled = false
//            tInnerView?.addSubview(tLabel)
//            // Make some space for label below button
//            tButton?.layer.affineTransform() = CGAffineTransform(translationX: 0.0, y: -buttonTitleFontSize / 1.9)
//        }
//        tInnerView?.tag = aTag + TAG_INNER_VIEW_OFFSET
//        if let aButton = tButton {
//            tInnerView?.addSubview(aButton)
//        }
//        if tapMode {
//            tButton?.addTarget(self, action: #selector(self.circleButtonTapped(_:)), for: .touchDown)
//            let temporaryRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
//            addGestureRecognizer(temporaryRecognizer)
//        }
//        if visualFxMode {
//            let tEffectsView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
//            tEffectsView.frame = CGRect(x: 0.0, y: 0.0, width: buttonRadius * 2, height: buttonRadius * 2)
//            tInnerView?.backgroundColor = UIColor.clear
//            if let aView = tInnerView {
//                tEffectsView.contentView.addSubview(aView)
//            }
//            tEffectsView.clipsToBounds = true
//            tEffectsView.layer.cornerRadius = buttonRadius
//            return tEffectsView
//        }
//        return tInnerView
//    }
//    /**
//     * Does the math to put buttons on a circle.
//     */
//
//    func calculateButtonPositions() {
//        if !clippingView {
//            // climb view hierarchy up, until first view with clipToBounds = YES
//            clippingView = clippingViewOfChild(self)
//        }
//        var tMaxX: CGFloat = frame.size.width - buttonRadius
//        var tMinX: CGFloat = buttonRadius
//        var tMaxY: CGFloat = frame.size.height - buttonRadius
//        var tMinY: CGFloat = buttonRadius
//        if (clippingView != nil) {
//            let tClippingFrame: CGRect = clippingView.convert(clippingView.bounds, to: self)
//            tMaxX = tClippingFrame.size.width + tClippingFrame.origin.x - buttonRadius * 2
//            tMinX = tClippingFrame.origin.x
//            tMaxY = tClippingFrame.size.height + tClippingFrame.origin.y - buttonRadius * 2
//            tMinY = tClippingFrame.origin.y
//        }
//        let tCounter: Int = 0
//        // issue #1 - align buttons perfectly on circle of max angle is 360.0
//        if maxAngle == 360.0 {
//            maxAngle = 360.0 - 360.0 / buttons.count
//        }
//        for tView: UIView? in buttons {
//            let tSize: CGSize? = tView?.frame.size
//            let tPoint: CGPoint = calculateButtonPosition(at: tCounter)
//            var tX: CGFloat = tPoint.x
//            var tY: CGFloat = tPoint.y
//            if tX > tMaxX {
//                tX = tMaxX
//            }
//            if tX < tMinX {
//                tX = tMinX
//            }
//            if tY > tMaxY {
//                tY = tMaxY
//            }
//            if tY < tMinY {
//                tY = tMinY
//            }
//            let tRect = CGRect(x: tX, y: tY, width: tSize?.width ?? 0.0, height: tSize?.height ?? 0.0)
//            tView?.frame = tRect
//            tCounter += 1
//        }
//    }
//     func calculateButtonPosition(at index: Int) -> CGPoint {
//        if absurdLineMode {
//            // Align button positions along a line starting at origin with startingAngle
//            let tSize: CGSize = buttons[index].frame().size
//            let tOrigin = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
//            let tDistance: CGFloat = radius + (Double(index) * (2 * buttonRadius + 8.0))
//            let tX: CGFloat = tOrigin.x - (tDistance * cosf(startingAngle / 180.0 * .pi)) - (tSize.width / 2)
//            let tY: CGFloat = tOrigin.y - (tDistance * sinf(startingAngle / 180.0 * .pi)) - (tSize.width / 2)
//            return CGPoint(x: tX, y: tY)
//        } else {
//            var tCurrentAngle: CGFloat
//            if buttons.count < 2 {
//                // #7 special (center) alignment, if there is only one button
//                tCurrentAngle = startingAngle + maxAngle / 2
//            } else {
//                tCurrentAngle = CGFloat(startingAngle + (maxAngle / (buttons.count - 1)) * index)
//            }
//            let tSize: CGSize = buttons[index].frame().size
//            let tOrigin = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
//            let tX: CGFloat = tOrigin.x - (radius * cosf(tCurrentAngle / 180.0 * .pi)) - (tSize.width / 2)
//            let tY: CGFloat = tOrigin.y - (radius * sinf(tCurrentAngle / 180.0 * .pi)) - (tSize.width / 2)
//            return CGPoint(x: tX, y: tY)
//        }
//    }
//    /**
//     * Climbs up the view hierarchy to find the first which has clipToBounds = YES.
//     * Returns the topmost view if no view has clipsToBound set to YES.
//     * @return UIView with clipToBounds = YES
//     */
//
//    func clippingViewOfChild(_ aView: UIView?) -> UIView? {
//        let tView: UIView? = aView?.superview
//        if tView != nil {
//            if tView?.clipsToBounds ?? false {
//                return tView
//            } else {
//                return clippingViewOfChild(tView)
//            }
//        } else {
//            return aView
//        }
//    }
//    func openMenu(with aRecognizer: UIGestureRecognizer?) {
//        recognizer = aRecognizer
//        // use target action to get notified upon gesture changes
//        recognizer?.addTarget(self, action: #selector(self.gestureChanged(_:)))
//        openMenu(with: aRecognizer)
//    }
//    func openMenu() {
//        let tOrigin = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
//        calculateButtonPositions()
//        for tButtonView: UIView? in buttons {
//            if let aView = tButtonView {
//                addSubview(aView)
//            }
//            tButtonView?.alpha = 0.0
//            let tDiffX: CGFloat = tOrigin.x - (tButtonView?.frame.origin.x ?? 0.0) - buttonRadius
//            let tDiffY: CGFloat = tOrigin.y - (tButtonView?.frame.origin.y ?? 0.0) - buttonRadius
//            tButtonView?.transform = CGAffineTransform(translationX: tDiffX, y: tDiffY)
//        }
//        var tDelay: CGFloat = 0.0
//        for tButtonView: UIView? in buttons {
//            tDelay = tDelay + animationDelay
//            UIView.animate(withDuration: 0.6, delay: TimeInterval(tDelay), usingSpringWithDamping: 0.5, initialSpringVelocity: 0.8, options: UIViewAnimationOptions(rawValue: UIViewAnimationOptions.curveEaseOut.rawValue | (allowAnimationInteraction ? UIViewAnimationOptions.allowUserInteraction.rawValue : 0)), animations: {
//                tButtonView?.alpha = 1.0
//                tButtonView?.transform = .identity
//            }) { finished in
//            }
//        }
//        if delegate && delegate.responds(to: #selector(self.circleMenuOpened)) {
//            delegate.circleMenuOpened()
//        }
//    }
//    /**
//     * Performs the closing animation.
//     */
//
//    @objc func closeMenu() {
//        if !tapMode {
//            recognizer?.removeTarget(self, action: #selector(self.gestureChanged(_:)))
//        }
//        UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseOut, animations: {
//            for tButtonView: UIView? in self.buttons {
//                if self.hoverTag > 0 && self.hoverTag == self.bareTagOf(tButtonView) {
//                    tButtonView?.transform = CGAffineTransform(scaleX: 1.8, y: 1.8)
//                }
//                tButtonView?.alpha = 0.0
//            }
//        }) { finished in
//            self.removeFromSuperview()
//            if self.delegate && self.delegate.responds(to: #selector(self.circleMenuClosed)) {
//                self.delegate.circleMenuClosed()
//            }
//        }
//    }
//    @objc func gestureMoved(to aPoint: CGPoint) {
//        let tView: UIView? = hitTest(aPoint, with: nil)
//        var tTag: Int = bareTagOf(tView)
//        if tTag > 0 {
//            if tTag == hoverTag {
//                // this button is already the active one
//                return
//            }
//            hoverTag = tTag
//            // display all (other) buttons in normal state
//            resetButtonState()
//            // display this button in active color
//            tTag = tTag + TAG_INNER_VIEW_OFFSET
//            let tInnerView: UIView? = viewWithTag(tTag)
//            tInnerView?.backgroundColor = innerViewActiveColor
//            if depth {
//                applyActiveDepth(toButtonView: tInnerView)
//            }
//        } else {
//            // the view "hit" is none of the buttons -> display all in normal state
//            resetButtonState()
//            hoverTag = 0
//        }
//    }
//    @objc func resetButtonState() {
//        for i in 1...buttons.count {
//            let tView: UIView? = viewWithTag(i + TAG_INNER_VIEW_OFFSET)
//            tView?.backgroundColor = innerViewColor
//            if depth {
//                applyInactiveDepth(toButtonView: tView)
//            }
//        }
//    }
//    @objc func applyInactiveDepth(toButtonView aView: UIView?) {
//        aView?.layer.shadowColor = UIColor.black.cgColor
//        aView?.layer.shadowOffset = CGSize(width: 4, height: 2)
//        aView?.layer.shadowRadius = 8
//        aView?.layer.shadowOpacity = 0.35
//        aView?.layer.affineTransform() = CGAffineTransform(scaleX: 1.0, y: 1.0)
//    }
//    @objc func applyActiveDepth(toButtonView aView: UIView?) {
//        aView?.layer.shadowColor = UIColor.black.cgColor
//        aView?.layer.shadowOffset = CGSize(width: 2, height: 1)
//        aView?.layer.shadowRadius = 5
//        aView?.layer.shadowOpacity = 0.42
//        aView?.layer.affineTransform() = CGAffineTransform(scaleX: 0.985, y: 0.985)
//    }
//    /**
//     * Target action method that gets called when the gesture used to open
//     * the CKCircleMenuView changes.
//     */
//
//    @objc func gestureChanged(_ sender: UILongPressGestureRecognizer?) {
//        if sender?.state == .changed {
//            let tPoint: CGPoint? = sender?.location(in: self)
//            gestureMoved(to: tPoint!)
//        } else if sender?.state == .ended {
//            // determine wether a button was hit when the gesture ended
//            let tPoint: CGPoint? = sender?.location(in: self)
//            let tView: UIView? = hitTest(tPoint ?? CGPoint.zero, with: nil)
//            let tTag: Int = bareTagOf(tView)
//            if tTag > 0 {
//                if delegate && delegate.responds(to: #selector(self.circleMenuActivatedButton(withIndex:))) {
//                    delegate.circleMenuActivatedButton(with: tTag - 1)
//                }
//            }
//            closeMenu()
//        }
//    }
//    func handleTap(_ sender: UITapGestureRecognizer?) {
//        closeMenu()
//    }
//
//    @objc func circleButtonTapped(_ sender: UIButton?) {
//        let tTag: Int = bareTagOfView(sender)
//        if tTag > 0 {
//            if delegate && delegate.responds(to: #selector(self.circleMenuActivatedButton(withIndex:))) {
//                delegate.circleMenuActivatedButton(with: tTag - 1)
//            }
//            // set as hover tag for activation animation
//            hoverTag = tTag
//        }
//        closeMenu()
//    }
//    /**
//     * Return the 'virtual' tag of the button, no matter which of its components
//     * (image, background, border) is passed as argument.
//     * @param aView view to be examined
//     * @return 'virtual' tag without offsets
//     */
//    func bareTagOf(_ aView: UIView?) -> Int {
//        var tTag = Int(aView?.tag)
//        if tTag > 0 {
//            if tTag >= TAG_INNER_VIEW_OFFSET {
//                tTag = tTag - TAG_INNER_VIEW_OFFSET
//            }
//            if tTag >= TAG_BUTTON_OFFSET {
//                tTag = tTag - TAG_BUTTON_OFFSET
//            }
//        }
//        return tTag
//    }
//
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//
//
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destinationViewController.
//        // Pass the selected object to the new view controller.
//    }
//    */
//}
//class CKRoundView {
//    func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
//        // Pythagoras a^2 + b^2 = c^2
//        let tRadius: CGFloat = bound.size.width / 2
//        let tDiffX: CGFloat = tRadius - point.x
//        let tDiffY: CGFloat = tRadius - point.y
//        let tDistanceSquared: CGFloat = tDiffX * tDiffX + tDiffY * tDiffY
//        let tRadiusSquared: CGFloat = tRadius * tRadius
//        return tDistanceSquared < tRadiusSquared
//    }
//}

