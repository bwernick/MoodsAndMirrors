//
//  LineChart.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/9/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit
import Charts

class LineChart: UIView {
    // Line graph properties
    let lineChartView = LineChartView()
    var lineDataEntry: [ChartDataEntry] = []
    // Chart data
//    var workoutDuration = [String]()
//    var beatsPerMinute = [String]()
    var MyMoods = [MoodObjectMO]()
    var moodIn: MoodObjectMO!
    var delegate: GetChartdata!{
        didSet{
            populateData()
            lineChartSetup()
        }
    }
    
    func populateData(){
        MyMoods = delegate.MyMoods
//        moodIn.mood = delegate.moodIn.mood
//        moodIn.date = delegate.moodIn.date
    }
    
    func lineChartSetup(){
        //Line chart config
        self.backgroundColor = UIColor.white
        self.addSubview(lineChartView)
        lineChartView.translatesAutoresizingMaskIntoConstraints = false
        lineChartView.topAnchor.constraint(equalTo: self.topAnchor, constant: 20).isActive = true
        lineChartView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        lineChartView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        lineChartView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        
        //Line chart animation
        lineChartView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInSine)
        
        //Line chart population
        setLineChart(dataPoints: MyMoods)   //, values: moodIn.date)
    }
    
    func setLineChart(dataPoints: [MoodObjectMO]) { //}, values: [MoodObjectMO]){
        // No data setup
        lineChartView.noDataTextColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        lineChartView.noDataText = "No data for the chart"
        lineChartView.backgroundColor = #colorLiteral(red: 0.8374180198, green: 0.8374378085, blue: 0.8374271393, alpha: 1)
        
        //Data point setup & color config
        var moods = [String]()
        for i in 0..<dataPoints.count{
            print(String((dataPoints[i].mood)!))
            print((dataPoints[i].date)!)
            print(Double((dataPoints[i].mood)!)!)
            let sDate = String((dataPoints[i].date)!)
            let index = sDate.index(sDate.startIndex, offsetBy: 3)
            let index2 = sDate.index(sDate.startIndex, offsetBy: 4)
            let month = String(sDate[index])+String(sDate[index2])
            print(Double(month)!)

            let dataPoint = ChartDataEntry(x: Double((dataPoints[i].mood)!)!, y: Double(month)!)
            lineDataEntry.append(dataPoint)
            moods.append(dataPoints[i].mood!)
        }
        
        let chartDataSet = LineChartDataSet(values: lineDataEntry, label: "Dates")
        let chartData = LineChartData()
        chartData.addDataSet(chartDataSet)
        chartData.setDrawValues(true) // false if you don't want values above the bar
        chartDataSet.colors = [UIColor.red]
        chartDataSet.setCircleColor(UIColor.red)
        chartDataSet.circleHoleColor = UIColor.red
        chartDataSet.circleRadius = 4.0
        
        // Gradient fill
        let gradientColors = [UIColor.red.cgColor, UIColor.clear.cgColor] as CFArray
        let colorLocations: [CGFloat] = [1.0, 0.0] // positioning of gradient
        guard let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)else {print("gradient error"); return}
        chartDataSet.fill = Fill.fillWithLinearGradient(gradient, angle: 90.0)
        chartDataSet.drawFilledEnabled = true
        
        //Axes setup
        let formatter: ChartFormatter = ChartFormatter()

        formatter.setValues(values: moods)
        let xaxis: XAxis = XAxis()
        xaxis.valueFormatter = formatter
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.drawGridLinesEnabled = false // true if you want X-Axis grid
        lineChartView.xAxis.valueFormatter = xaxis.valueFormatter
        lineChartView.chartDescription?.enabled = false
        lineChartView.legend.enabled = true
        lineChartView.rightAxis.enabled = true
        lineChartView.leftAxis.drawGridLinesEnabled = false // true if you want Y-Axis grid
        lineChartView.leftAxis.drawLabelsEnabled = true
        lineChartView.xAxis.drawLabelsEnabled = true
        lineChartView.data = chartData
    }
    
}
