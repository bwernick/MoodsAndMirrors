//
//  GraphsViewController.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/4/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit
import Charts
import CoreData

protocol GetChartdata{
 //   func getChartData(with dataPoints: [MoodObjectMO])  //, values:[MoodObjectMO])
//    var workoutDuration: [String] {get set}
//    var beatsPerMinute: [String] {get set}
    var MyMoods : [MoodObjectMO] {get set}
//    var moodArray : [MoodObjectMO] {get set}
//    var dateArray : [MoodObjectMO] {get set}
}
class GraphsViewController: UIViewController, GetChartdata, NSFetchedResultsControllerDelegate {
    
    // Chart Data
//    var workoutDuration = [String]()
//    var beatsPerMinute = [String]()
    
    
    var fetchResultsController : NSFetchedResultsController<MoodObjectMO>!
    
    //get data from MoodObjectMO
    //var MyMoodObject : [MoodObjectMO] = []
//    var moodArray = [MoodObjectMO]()
//    var dateArray = [MoodObjectMO]()
    var MyMoods : [MoodObjectMO] = []
    var moodfetchResultsController : NSFetchedResultsController<MoodObjectMO>!
    var moods = [ MoodObject(mood: "3", date: "23/11/1989"),
                  MoodObject(mood:"1", date: "10/04/2018")]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let firstRun = UserDefaults.standard.bool(forKey: "MoodKey") as Bool
        if !firstRun {
            //run your function
            seedMood()
            UserDefaults.standard.set(true, forKey: "MoodKey")
        }
        
        let fetchRequest : NSFetchRequest<MoodObjectMO> = MoodObjectMO.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "mood", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            let context = appDelegate.persistentContainer.viewContext
            moodfetchResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            moodfetchResultsController.delegate = self
            do {
                try moodfetchResultsController.performFetch()
                if let fetchObjects = moodfetchResultsController.fetchedObjects{
                    MyMoods = fetchObjects
                    for i in 0..<MyMoods.count {
                        print(String(describing: MyMoods[i].mood))
                        print(MyMoods[i].date)
                    }
                }
            } catch {
                print(error)
            }
        }
        
//        for x in MyMoods{
//            moodArray.append(MyMoods[x].mood!)
//            dateArray.append(MyMoods[x].date!)
//        }
        // Do any additional setup after loading the view.
        //Populate chart data
        //populateChartData()
        //Bar chart
        //barChart()
        //Line chart
        lineChart()
        
        //Cubic line chart
        //cubicChart()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.view.setNeedsLayout()
//        self.barChart()
        self.lineChart()
    }
    
    func seedMood()
    {
        var seedMood: MoodObjectMO!
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            for m in moods{
                seedMood = MoodObjectMO(context: appDelegate.persistentContainer.viewContext)
                seedMood.mood = m.mood
                seedMood.date = m.date
                appDelegate.saveContext()
            }
        }
    }
  
    // Chart options
//    func populateChartData(){
//        //workoutDuration = ["1","2","3","4","5","6","7","8","9","10"]
//        //beatsPerMinute = ["76","150","160","180","195","195","180","164","136","112"]
//        //self.getChartData(with: workoutDuration, values: beatsPerMinute)
////        dateArray = ["01/01/2018", "01/02/2018", "01/03/2018", "01/04/2018", "01/05/2018"]
////        moodArray = ["3", "3", "2", "2", "3"]
//        self.getChartData(with: MyMoods)  //, values: moodArray)
//    }
//    func barChart(){
//        let barChart = BarChart(frame: CGRect(x:0.0, y: 0.0, width: self.view.frame.width,height: self.view.frame.height))
//        barChart.delegate = self
//        self.view.addSubview(barChart)
//    }
    func lineChart(){
        let lineChart = LineChart(frame: CGRect(x: 0.0, y: 0.0, width: self.view.frame.width, height: self.view.frame.height))
        lineChart.delegate = self
        self.view.addSubview(lineChart)
    }
//    func cubicChart(){
//        let cubicChart = CubicChart(frame: CGRect(x: 0.0, y: 0.0, width: self.view.frame.width, height: self.view.frame.height))
//        cubicChart.delegate = self
//        self.view.addSubview(cubicChart)
//    }
    //Conform to protocol
//    var moodTime : MoodObjectMO!
//    func getChartData(with dataPoints: [MoodObjectMO]) {  //, values: [MoodObjectMO]) {
//        self.MyMoodsCh = dataPoints
////        self.moodTime.mood = dataPoints.text
////        self.moodTime.date = values.text
//    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - ChartFormatter required to config xaxis
 
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
}
public class ChartFormatter: NSObject, IAxisValueFormatter{
    var dates = [String]()
    public func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return dates[Int(value)]
    }
    public func setValues(values: [String]){
        self.dates = values
    }
    

}
