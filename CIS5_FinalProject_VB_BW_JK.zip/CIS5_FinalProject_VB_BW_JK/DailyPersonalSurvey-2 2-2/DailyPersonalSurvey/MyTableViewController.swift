//
//  MyTableViewController.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/4/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit
import CoreData
import AVFoundation
import FLAnimatedImage

class MyTableViewController: UITableViewController, UISearchResultsUpdating,NSFetchedResultsControllerDelegate {
    
    var MyQuestions : [QuestionObjectMO] = []
    var fetchResultsController : NSFetchedResultsController<QuestionObjectMO>!
    var searchQuestion : [QuestionObjectMO] = []
    var searchQuestionController : UISearchController!
    var questions = [
        QuestionObject(question: "What time did you sleep last night?", response: "10 PM"),
        QuestionObject(question: "What time did you wake up this morning?", response: "7 AM"),
        QuestionObject(question: "Have you had breakfast yet?" , response: "Yes"),
        QuestionObject(question: "What tasks do you have to complete today?", response: "Laundry, Work, Errands, Water Plants"),
        QuestionObject(question: "Which tasks are high prioroty?", response: "Work, Errands"),
        QuestionObject(question: "What's your plan of attack?", response: "Work until 12, eat lunch, work until 4. Errand after 6"),
        QuestionObject(question: "Do you have any deadlines? If so, when?", response:"Deadline at 12"),
        QuestionObject(question: "Are you working alone or in a group today?", response: "Alone"),
        QuestionObject(question: "Where will you be while working?", response: "Home"),
        QuestionObject(question: "How do you plan to reward yourself?", response: "Coffee"),
        QuestionObject(question: "What time will you take a stretch break?", response: "3 PM")
        ]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       // Music Player
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            print("AVAudioSession Category Playback OK")
            do {
                try AVAudioSession.sharedInstance().setActive(true)
                print("AVAudioSession is Active")
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        //playBackgroundMusic(filename: "Spirited Away (2001) - The Name of Life (Instrumental piano) Inochi No Namae いのちの名前.mp3")
        //Hidden on start of view
        //playSound()
        let firstRun = UserDefaults.standard.bool(forKey: "SomeKeyName") as Bool
        if !firstRun {
            //run your function
            seedToDataBase()
            UserDefaults.standard.set(true, forKey: "SomeKeyName")
        }
        
        self.tableView.backgroundColor = UIColor.clear
        self.tableView.backgroundView = UIImageView(image: #imageLiteral(resourceName: "waves2"))
        self.tableView.backgroundView?.contentMode = .scaleAspectFit
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "",style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        // Add a searchController and searchBar to the app
        
        self.searchQuestionController = UISearchController(searchResultsController: nil)
        self.searchQuestionController.searchBar.sizeToFit()
        self.searchQuestionController.hidesNavigationBarDuringPresentation = false
        self.searchQuestionController.searchResultsUpdater = self
        self.searchQuestionController.dimsBackgroundDuringPresentation = false
        self.tableView.tableHeaderView = self.searchQuestionController.searchBar
        
        let fetchRequest : NSFetchRequest<QuestionObjectMO> = QuestionObjectMO.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "question", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            let context = appDelegate.persistentContainer.viewContext
            fetchResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            fetchResultsController.delegate = self
            do {
                try fetchResultsController.performFetch()
                if let fetchObjects = fetchResultsController.fetchedObjects{
                    MyQuestions = fetchObjects
                   // createPeopleDict ()
                }
            } catch {
                print(error)
            }
        }
        
    }

    override func viewDidAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            if let newIndexPath = newIndexPath{
                tableView.insertRows(at: [newIndexPath], with: .fade)
            }
        case .delete:
            if let indexPath = indexPath{
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
        case .update:
            if let indexPath = indexPath{
                tableView.reloadRows(at: [indexPath], with: .fade)
                
            }
        default:
            tableView.reloadData()
            if let fetchedObjects = controller.fetchedObjects{
                MyQuestions = fetchedObjects as! [QuestionObjectMO]
            }
            
        }
    }
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchQuestionController.isActive{
            return 1
        }else{
            return MyQuestions.count
        }

    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //return animeSectionTitles[section]
        if searchQuestionController.isActive{
            return "Search Result"
        }else{
            return "My Questions"
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "QuestionCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! MyTableViewCell
        var cellItem : QuestionObjectMO
        if searchQuestionController.isActive{
            cellItem = searchQuestion[indexPath.row]
        }else{
            cellItem = MyQuestions[indexPath.row]
        }
         // Configure the cell
        cell.cellQuestion?.text = cellItem.question
//        cell.cellQuestionNumber?.text = cellItem.qNum
       cell.backgroundColor = UIColor.clear
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            return
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
            if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
                let context = appDelegate.persistentContainer.viewContext
                //let delItem = self.tableveiw.cell.animeName?.text
                
                let itemToDelete = self.fetchResultsController.object(at: indexPath)
                
                context.delete(itemToDelete)
                do{
                    appDelegate.saveContext()
                }
        }    
    }
}
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Question"
        {
            if let indexPath = self.tableView.indexPathForSelectedRow{
                let detailVC = segue.destination as! MyDetailViewController
                detailVC.QuestionDetail = searchQuestionController.isActive ? searchQuestion[indexPath.row] : MyQuestions[indexPath.row]
            }
        }
//        else if segue.identifier == "AddNewItem"{
//            let addVC = segue.destination as! AddViewController
//             addVC.newQuestion = addData
//        }
    }
    func addData(newItem: QuestionObjectMO)
    {
        MyQuestions.append(newItem)
    }
    
    func seedToDataBase()
    {
        var seedQuestion: QuestionObjectMO!
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            for o in self.questions{
                seedQuestion = QuestionObjectMO(context: appDelegate.persistentContainer.viewContext)
                seedQuestion.question = o.question
               // seedQuestion.qNum = o.qNum
                seedQuestion.response = o.response
               // seedQuestion.time = o.time as NSObject
                //newAnime.aImage = NSData(data: UIImageJPEGRepresentation(UIImage(named: addAnimeImage.text!)!, 1.0)!) as Data!
                //seedAnime.aImage = NSData(data: UIImagePNGRepresentation(o.aImage)!) as Data!
                appDelegate.saveContext()
            }
        }
    }

    func filterContentforSearchText(searchText: String)
    {
        searchQuestion = MyQuestions.filter({(questionItem: QuestionObjectMO) -> Bool in
            let nameMatch = questionItem.question?.range(of: searchText,options: String.CompareOptions.caseInsensitive)
            return (nameMatch != nil)
        })
    }
    func updateSearchResults(for searchController: UISearchController)
    {
        if let questionToSearch = searchQuestionController.searchBar.text{
            filterContentforSearchText(searchText: questionToSearch)
            tableView.reloadData()
        }
    }
    var backgroundMusicPlayer = AVAudioPlayer()
    
    func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }
        do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }

}
