//
//  DataViewController.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/11/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit
import CKCircleMenuView
import CoreData

class DataViewController: UIViewController, CKCircleMenuDelegate,UIGestureRecognizerDelegate, NSFetchedResultsControllerDelegate{
    @IBOutlet var txtDatePicker: UITextField!
    @IBOutlet var buttonCountSlider: UISlider!
    @IBOutlet var angleSlider: UISlider!
    @IBOutlet var delaySwitch: UISwitch!
    @IBOutlet var shadowSwitch: UISwitch!
    @IBOutlet var directionSegmentedControl: UISegmentedControl!
    @IBOutlet var demoTapButton: UIButton!
    @IBOutlet var radiusSlider: UISlider!
    
    var imageArray = [Any]()
    var angle: CGFloat = 0.0
    var delay: CGFloat = 0.0
    var shadow: Int = 0
    var radius: CGFloat = 0.0
    var direction: Int = 0
    var circleMenuView: CKCircleMenuView?
    var allDates : String = ""
    var allMoods : String = ""
    var graphs : GraphsViewController?
    
    var circleMenuImageArray = Array<UIImage>()
    let datePicker = UIDatePicker()
    
    /*guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
    let managedContent = appDelegate.persistanceContainer.viewContext
    let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext)!
    
    let user = NSManagedObject(entity: userEntity, insertInto: managedContent)
    user.setValue("John", forKeyPath: "name")
    user.setValue("john@test.com", forKeyPath: "email")
    
    let formatting = DateFormatter()
    formatter.dateFormat = "dd/mm/yyyy"
    let date = formatter.date(from: "08/10/1990")
    user.setValue(date, forKey: "date_of_birth")
    user.setValue(0, forKey: "number_of_children")
     */
 
    override func viewDidLoad() {
        super.viewDidLoad()
        showDatePicker()
        self.circleMenuImageArray.append(UIImage(named: "sad.png")!)
        self.circleMenuImageArray.append(UIImage(named: "meh.png")!)
        self.circleMenuImageArray.append(UIImage(named: "smile.png")!)
        direction = Int(CircleMenuDirectionUp.rawValue)
        delay = 0.0
        shadow = 0
        radius = 65.0
        angle = 180.0
        
        self.buttonCountSlider.isHidden = true
        self.angleSlider.isHidden = true
        self.delaySwitch.isHidden = true
        self.shadowSwitch.isHidden = true
        self.radiusSlider.isHidden = true
        self.directionSegmentedControl.isHidden = true
        
       // self.view.layer.backgroundColor = (UIColor.clear as! CGColor)
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "waterWallpaper")!)
       // self.view.contentScaleFactor = .s
        //self.demoTapButton.layer.cornerRadius = 10
        //self.demoTapButton.layer.backgroundColor = UIColor.blue as! CGColor
        
       /* let fetchRequest : NSFetchRequest<MoodObjectMO> = MoodObjectMO.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "Date", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            let context = appDelegate.persistentContainer.viewContext
            moodfetchResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            moodfetchResultsController.delegate = self
            do {
                try moodfetchResultsController.performFetch()
                if let fetchObjects = moodfetchResultsController.fetchedObjects{
                    MyMoods = fetchObjects
                }
            } catch {
                print(error)
            }
        }*/
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        if(allDates.isEmpty || allMoods.isEmpty){
            return
        }
        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
            let newMoodObject = MoodObjectMO(context: appDelegate.persistentContainer.viewContext)
            newMoodObject.date = self.allDates
            newMoodObject.mood = self.allMoods
            appDelegate.saveContext()
        }
//        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
//        let managedContext = appDelegate.persistentContainer.viewContext
//
//        let MoodEntity = NSEntityDescription.entity(forEntityName: "MoodObjectMO", in: managedContext)!
//        let Mood = NSManagedObject(entity: MoodEntity, insertInto: managedContext)
//
//        Mood.setValue(allDates, forKeyPath: "date")
//        Mood.setValue(allMoods, forKey: "mood")
//        //let formatter = DateFormatter()
//        //formatter.dateFormat = "dd/mm/yyyy"
//        //let date = formatter.date(from: "08/10/1990")
//        //  Mood.setValue(date, forKey: "date")
//        //  Mood.setValue(0, forKey: "number_of_children"
//
//        do {
//            try managedContext.save()
//        } catch let error as NSError {
//            print("Could not save. \(error), \(error.userInfo)")
//        }
    }

    @IBAction func buttonCountChanged(_ sender: UISlider) {
//        var tArray = [AnyHashable]()
//        for i in 0..<CGFloat(sender.value){
//            if let aNamed = UIImage(named: "meh.png") {
//                tArray.append(aNamed)
//            }
//        }
//        imageArray = tArray
    }
    @IBAction func angleChanged(_ sender: UISlider) {
        angle = CGFloat(sender.value)
    }
    
    @IBAction func delayChanged(_ sender: UISwitch) {
        if sender.isOn {
            delay = 0.1
        } else {
            delay = 0.0
        }
    }
    
    @IBAction func shadowChanged(_ sender: UISwitch) {
        if sender.isOn {
            shadow = 1
        } else {
            shadow = 0
        }
    }

    @IBAction func radiusChanged(_ sender: UISlider) {
        radius = CGFloat(sender.value)
    }
    
    @IBAction func directionChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            direction = Int(CircleMenuDirectionUp.rawValue)
        case 1:
            direction = Int(CircleMenuDirectionDown.rawValue)
        case 2:
            direction = Int(CircleMenuDirectionLeft.rawValue)
        case 3:
            direction = Int(CircleMenuDirectionRight.rawValue)
        default:
            print("Invalid Direction")
        }
    }
    
    @IBAction func demoTapButtonTouchUpInside(_ sender: UIButton) {
        if (circleMenuView != nil) {
            circleMenuView?.closeMenu()
            circleMenuView = nil
            demoTapButton.setTitle("Open", for: .normal)
        } else {
            var tPoint = CGPoint(x: sender.bounds.midX, y: sender.bounds.midY)
            tPoint = view.convert(tPoint, from: sender)
            var tOptions = [AnyHashable: Any]()
            tOptions[CIRCLE_MENU_OPENING_DELAY] = delay
            tOptions[CIRCLE_MENU_MAX_ANGLE] = angle
            tOptions[CIRCLE_MENU_RADIUS] = radius
            tOptions[CIRCLE_MENU_DIRECTION] = direction
            tOptions[CIRCLE_MENU_BUTTON_BACKGROUND_NORMAL] = UIColor(red: 0.0, green: 0.25, blue: 0.5, alpha: 1.0)
            tOptions[CIRCLE_MENU_BUTTON_BACKGROUND_ACTIVE] = UIColor(red: 0.25, green: 0.5, blue: 0.75, alpha: 1.0)
            tOptions[CIRCLE_MENU_BUTTON_BORDER] = UIColor.white
            tOptions[CIRCLE_MENU_DEPTH] = shadow
            tOptions[CIRCLE_MENU_BUTTON_RADIUS] = NSDecimalNumber(string: "40.0")
            tOptions[CIRCLE_MENU_BUTTON_BORDER_WIDTH] = NSDecimalNumber(string: "2.5")
            tOptions[CIRCLE_MENU_TAP_MODE] = 1
            tOptions[CIRCLE_MENU_LINE_MODE] = 1
            tOptions[CIRCLE_MENU_BACKGROUND_BLUR] = 1
            tOptions[CIRCLE_MENU_BUTTON_TINT] = 1
            
            let tMenu = CKCircleMenuView.init(atOrigin: tPoint, usingOptions: tOptions, withImageArray: circleMenuImageArray)
            tMenu?.delegate = self
            view.addSubview(tMenu!)
            tMenu?.openMenu()
            circleMenuView = tMenu
            
        }
    }
//    self.circleMenuView = CKCircleMenuView(atOrigin: tPoint, usingOptions: tOptions, withImageArray: self.circleMenuImageArray)
//    self.view.addSubview(self.circleMenuView!)
//    self.circleMenuView!.delegate = self
//    self.circleMenuView!.openMenu()
    //-------------------------------------------------------------------------------------
  

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //----------------------------------------------------------------------------------

    func showDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        txtDatePicker.inputAccessoryView = toolbar
        txtDatePicker.inputView = datePicker
        
    }
   
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        txtDatePicker.text = formatter.string(from: datePicker.date)
        self.allDates = txtDatePicker.text!
        
        //let date = ["date" : txtDatePicker.text!]
        print(allDates)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    // MARK: Circle Menu Delegate
    
     func circleMenuActivatedButton(with anIndex: Int32) {
        self.allMoods = "\(anIndex)"    //get the mood via Int
        let tController : UIAlertController
        if(anIndex == 0){
            tController = UIAlertController(title: "Mood", message: "Sad", preferredStyle: .alert)
        }else if(anIndex == 1){
            tController = UIAlertController(title: "Mood", message: "Meh", preferredStyle: .alert)
        }else{
            tController = UIAlertController(title: "Mood", message: "Happy", preferredStyle: .alert)
        }
        
        tController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(tController, animated: true) {
            self.circleMenuView = nil
            self.demoTapButton.setTitle("Open", for: .normal)
        }
      
    }

    func circleMenuOpened() {
        demoTapButton.setTitle("Close", for: .normal)
    }
    
    func circleMenuClosed() {
        if (circleMenuView != nil) {
            circleMenuView?.closeMenu()
            circleMenuView = nil
        }
     demoTapButton.setTitle("Open", for: .normal)
    }
    
}
