//
//  QuestionObject.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/9/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit

class QuestionObject: NSObject {
    var question = ""
//    var qNum = ""// Question Number
    var response = ""
//    var time : [String] = []
//    var category = ""
    init(question : String, response: String){
        self.question = question
       // self.qNum = qNum
        self.response = response
       // self.time = time
        //self.category = category
    }
}
