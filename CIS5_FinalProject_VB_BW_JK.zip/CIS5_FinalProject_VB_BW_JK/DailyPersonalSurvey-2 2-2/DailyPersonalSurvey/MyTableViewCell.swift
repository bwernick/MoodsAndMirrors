//
//  MyTableViewCell.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/4/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    
    @IBOutlet var cellQuestionNumber: UILabel!
    @IBOutlet var cellQuestion: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
