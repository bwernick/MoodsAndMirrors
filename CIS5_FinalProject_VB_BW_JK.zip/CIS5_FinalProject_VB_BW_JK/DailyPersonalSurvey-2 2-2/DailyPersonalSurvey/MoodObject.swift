//
//  MoodObject.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/18/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit

class MoodObject: NSObject {
    var mood : String
    var date : String
    
    init(mood: String, date: String){
        self.mood = mood
        self.date = date
    }
}
