//
//  MyDetailViewController.swift
//  DailyPersonalSurvey
//
//  Created by Vera Boukhonine, Bradley Wernick, Jasmine Kilani  on 6/4/18.
//  Copyright © 2018 DeAnza. All rights reserved.
//

import UIKit

class MyDetailViewController: UIViewController {
//    @IBOutlet var questionNum: UILabel!
    @IBOutlet var textBox: UITextView!// holds my questions
    @IBOutlet var responseQ: UITextView!// gives my default example responses
    var QuestionDetail: QuestionObjectMO!
    
    @IBAction func infoButtonPushed(_ sender: UIButton) {
        if self.textBox.isHidden == true {
            //"fade out" the hidden text box so that it can fade in
            UIView.animate(withDuration: 0.0, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.textBox.alpha = 0.0
            }, completion: {
                (finished: Bool) -> Void in
                //make info box not hidden
                self.textBox.isHidden = false
                //fade in
                UIView.animate(withDuration: 0.7, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    self.textBox.alpha = 1.0
                }, completion: nil)
            })
        }else{
            //fade out
            UIView.animate(withDuration: 0.7, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.textBox.alpha = 0.0
            }, completion: {
                (finished: Bool) -> Void in
                //make info box hidden
                self.textBox.isHidden = true
            })
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       // var responseArray : String!
        textBox.isHidden = true
        // Do any additional setup after loading the view.
       self.view.backgroundColor = UIColor(patternImage: UIImage(named: "waterWallpaper")!)
//       self.questionNum.text = self.QuestionDetail.qNum
        
        
        
       self.textBox.text = self.QuestionDetail.question
       self.responseQ.text = self.QuestionDetail.response
        
        navigationItem.title = self.textBox.text
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func saveResponse(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
